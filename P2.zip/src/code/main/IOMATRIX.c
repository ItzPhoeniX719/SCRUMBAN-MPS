#include <stdio.h>
#include <stdlib.h>
#include "IOMATRIX.h"
#include "OPMATRIX.h"
#include "log.h"

Matriz matrixLoad(const char* filename) {
    FILE* f = fopen(filename, "r");
    if(f == NULL) {
        matrixLog("Fichero no existente", 1);
        perror("");
        exit(1);
    }

    Matriz m;               // Matriz resultante
    int valor, cont = 0;

    while(fscanf(f, "%d", &valor) == 1) {
        int i = cont / 5;
        int j = cont % 5;
        if(i >= 5) {  // Más de 25 elementos
            matrixLog("Fichero contiene demasiados elementos", 1);
            fprintf(stderr, "Error: fichero contiene más de 25 elementos.\n");
            exit(1);
        }
        m.mat[i][j] = valor;
        cont++;
    }

    if(cont < 25) {  // Menos de 25 elementos
        matrixLog("Fichero contiene menos elementos de los requeridos", 1);
        fprintf(stderr, "Error: fichero contiene menos de 25 elementos.\n");
        exit(1);
    }

    fclose(f);
    matrixLog("Carga de matriz", 0);  // LOG: carga matriz OK
    return m;
}


void matrixSave(Matriz m, const char* filename){
    FILE* f;
    f = fopen(filename, "w");
    if(f == NULL){
        matrixLog("Error al abrir el fichero", 1);
        perror("");
        exit(1);
    }

    int i = 0; int j = 0;
    for(i; i<5; i++){
        for(j = 0; j<5; j++){
            fprintf(f, "%d ", m.mat[i][j]);
        }
        fprintf(f, "\n");
    }

    fclose(f);
    matrixLog("Guardar matriz", 0);   //LOG: guardar matriz OK
}

void matrixPrint(const Matriz m){
    int i = 0; int j = 0;
    for(i; i<5; i++){
        for(j = 0; j<5; j++){
            printf("%d ", m.mat[i][j]);
        }
        printf("\n");
    }
    matrixLog("Imprimir matriz", 0);  //LOG: imprimir matriz OK
}
