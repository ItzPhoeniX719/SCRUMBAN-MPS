#ifndef _IOMATRIX_H
#define _IOMATRIX_H

#include "OPMATRIX.h"

//Carga y guardado de matrices:
Matriz matrixLoad(const char* filename);
void matrixSave(const Matriz m, const char* filename);
void matrixPrint(const Matriz m);

//Errores:
void errorHandler();

#endif // _IOMATRIX_H