#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "log.h"

void matrixLog(const char* motivo, int estado) 
{
    FILE *f = fopen("log.txt", "a");
    if (!f) 
    {
        perror("Error en apertura log.\n");
        exit(1);
    }

    time_t ahora = time(NULL);
    struct tm *tinfo = localtime(&ahora);
    char hora[9];
    strftime(hora, sizeof(hora), "%H:%M:%S", tinfo);

    const char* estadoStr = (estado == 0) ? "OK" : "ERROR";

    fprintf(f, "[%s, %s, %s]\n", hora, motivo, estadoStr);
    fclose(f);
}

void opLog(const char* tipoOp)
{
    FILE *f = fopen("log.txt", "a");
    if (!f) 
    {
        perror("Error en apertura log.\n");
        exit(1);
    }

    time_t ahora = time(NULL);
    struct tm *tinfo = localtime(&ahora);
    char hora[9];
    strftime(hora, sizeof(hora), "%H:%M:%S", tinfo);

    fprintf(f, "[%s, %s]\n", hora, tipoOp);

    fclose(f);
}

void logFinEjecucion()
{
    FILE *f = fopen("log.txt", "a");
    if (!f) 
    {
        perror("Error en apertura log.\n");
        exit(1);
    }

    fprintf(f, "=========================== FIN DE EJECUCION ANTERIOR ===========================\n\n");
    fclose(f);
}

void mostrarLog() {
    FILE *f = fopen("log.txt", "r");
    if (!f) {
        printf("\tNo se pudo abrir el archivo log.txt.\n");
        return;
    }

    char linea[200];
    while (fgets(linea, sizeof(linea), f))
        printf("\t%s", linea);

    fclose(f);
}

