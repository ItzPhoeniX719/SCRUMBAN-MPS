#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "IOMATRIX.h"
#include "OPMATRIX.h"
#include "log.h"

#define N 5

// Prototipos
Matriz suma(Matriz A, Matriz B);
Matriz resta(Matriz A, Matriz B);
Matriz productoEscalar(int escalar, Matriz A);
Matriz producto(Matriz A, Matriz B);
Matriz traspuesta(Matriz A);
int esSimetrica(Matriz A);
Matriz matrixLoad(const char* filename);
void matrixSave(const Matriz m, const char* filename);
void matrixPrint(const Matriz m);
void mostrarLog();

int main() {
    int opcion, k, modo;
    Matriz A, B, R;
    char ficheroA[100], ficheroB[100];

    // Pantalla de bienvenida
    system("cls");
    printf("==============================================================\n");
    printf("|\t\t CALCULADORA DE MATRICES 5x5 \t\t     |\n");
    printf("|--------------------------------------------------------------|\n");
    printf("|\tOperaciones: suma, resta, producto y mas.\t     |\n");
    printf("==============================================================\n\n");

    do {
        // Limpia pantalla y muestra el menú principal
        system("cls");

        printf("\n\t=============================================\n");
        printf("\t\t       MENU PRINCIPAL\n");
        printf("\t=============================================\n\n");
        printf("\t[1] Suma de matrices (R = A + B)\n");
        printf("\t[2] Resta de matrices (R = A - B)\n");
        printf("\t[3] Multiplicacion de matrices (R = A * B)\n");
        printf("\t[4] Producto escalar (R = k * A)\n");
        printf("\t[5] Traspuesta de una matriz\n");
        printf("\t[6] Comprobar si una matriz es simetrica\n");
        printf("\t[7] Guardar matriz en fichero\n");
        printf("\t[8] Mostrar el contenido del log\n");
        printf("\t[9] Salir\n");
        printf("\n\tSelecciona una opcion: ");
        scanf("%d", &opcion);

        // Operaciones que requieren matriz
        if (opcion >= 1 && opcion <= 6) {
            printf("\n\tSelecciona el modo de entrada de la matriz:\n");
            printf("\t[1] Introducir manualmente\n");
            printf("\t[2] Cargar desde fichero\n");
            printf("\tOpcion: ");
            scanf("%d", &modo);

            if (modo == 1) {
                printf("\n\tIntroduce los elementos de la matriz A:\n");
                for (int i = 0; i < N; i++) {
                    for (int j = 0; j < N; j++) {
                        printf("\tA[%d][%d]: ", i, j);
                        scanf("%d", &A.mat[i][j]);
                    }
                }

                if (opcion >= 1 && opcion <= 3) {
                    printf("\n\tIntroduce los elementos de la matriz B:\n");
                    for (int i = 0; i < N; i++) {
                        for (int j = 0; j < N; j++) {
                            printf("\tB[%d][%d]: ", i, j);
                            scanf("%d", &B.mat[i][j]);
                        }
                    }
                }

            } else if (modo == 2) {
                printf("\n\tIntroduce el nombre del fichero de la matriz A: ");
                scanf("%s", ficheroA);
                A = matrixLoad(ficheroA);

                if (opcion >= 1 && opcion <= 3) {
                    printf("\tIntroduce el nombre del fichero de la matriz B: ");
                    scanf("%s", ficheroB);
                    B = matrixLoad(ficheroB);
                }
            } else {
                printf("\n\tOpcion de modo no valida. Volviendo al menu principal...\n");
                continue;
            }
        }

        // --- Ejecución de la operación seleccionada ---
        switch (opcion) {
            case 1:
                printf("\n\tPresiona ENTER para calcular la suma...");
                getchar(); getchar();

                system("cls");
                R = suma(A, B);
                opLog("SUMA");

                printf("\n\t=========== RESULTADO DE LA SUMA ===========\n\n");
                matrixPrint(R);
                break;

            case 2:
                printf("\n\tPresiona ENTER para calcular la resta...");
                getchar(); getchar();

                system("cls");
                R = resta(A, B);
                opLog("RESTA");

                printf("\n\t=========== RESULTADO DE LA RESTA ===========\n\n");
                matrixPrint(R);
                break;

            case 3:
                printf("\n\tPresiona ENTER para calcular el producto...");
                getchar(); getchar();

                system("cls");
                R = producto(A, B);
                opLog("PRODUCTO");

                printf("\n\t========= RESULTADO DEL PRODUCTO =========\n\n");
                matrixPrint(R);
                break;

            case 4:
                printf("\n\tIntroduce el valor del escalar k: ");
                scanf("%d", &k);

                printf("\n\tPresiona ENTER para calcular el producto escalar...");
                getchar(); getchar();

                system("cls");
                R = productoEscalar(k, A);
                opLog("PRODESC");

                printf("\n\t==== RESULTADO DEL PRODUCTO ESCALAR ====\n\n");
                matrixPrint(R);
                break;

            case 5: 
                printf("\n\tPresiona ENTER para calcular la traspuesta...");
                getchar(); getchar();

                system("cls");
                R = traspuesta(A);
                opLog("TRASPUESTA");

                printf("\n\t==== RESULTADO DE LA TRASPUESTA ====\n\n");
                matrixPrint(R);
                break;
            case 6:
                system("cls");
                if (simetrica(A))
                    printf("\n\tLa matriz introducida ES SIMETRICA.\n");
                else
                    printf("\n\tLa matriz introducida NO es simetrica.\n");
                opLog("SIMETRICA");
                break;
            case 7:
                char f[100];
                Matriz matGuardar;

                printf("\n\tIntroduce los elementos de la matriz a guardar:\n");
                for (int i = 0; i < N; i++) {
                    for (int j = 0; j < N; j++) {
                        printf("\tA[%d][%d]: ", i, j);
                        scanf("%d", &matGuardar.mat[i][j]);
                    }
                }

                int c;
                while ((c = getchar()) != '\n' && c != EOF) {}

                printf("\n\tNombre del fichero (incluye extension): ");
                fgets(f, sizeof(f), stdin);
                f[strcspn(f, "\n")] = '\0';

                matrixSave(matGuardar, f);
                printf("\n\tMatriz guardada correctamente en '%s'\n", f);
                break;
            case 8:
                system("cls");
                printf("\n\t====== CONTENIDO DEL ARCHIVO LOG ======\n\n");
                mostrarLog();
                printf("\n\t======================================\n");
                opLog("LOG");
                break;
            case 9:
                printf("\n\tSaliendo del programa...\n");
                logFinEjecucion();
                break;

            default:
                printf("\n\tOpcion no valida. Intente nuevamente.\n");
                break;
        }

        if (opcion != 9) {
            printf("\n\tPresiona ENTER para volver al menu principal...");
            getchar(); getchar();
        }

    } while (opcion != 9);

    return 0;
}
